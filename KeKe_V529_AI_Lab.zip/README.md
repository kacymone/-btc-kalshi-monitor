# KeKe V5.29 AI Lab — deployment

## Files
- `main.py`: V5.28 visible shadow plus AI Lab integration, derived from the uploaded V5.27 source.
- `keke_ai_lab.py`: independent AI analysis, SQLite logging, and approval-gated research.

Both files must be in the **same GitHub repository folder**. Replace the repository's existing `main.py` with the supplied `main.py`; add `keke_ai_lab.py`. Preserve your existing Railway volume at `/data`.

## Railway variables
- `OPENAI_API_KEY`: your own OpenAI API key (create in OpenAI API platform; billed separately from ChatGPT).
- `KEKE_AI_MODEL`: optional, default `gpt-4.1-mini` (verify model access on your account).
- `KEKE_AI_INTERVAL`: optional, default `60` seconds; minimum 30 seconds.
- `KEKE_AI_RESEARCH_INTERVAL`: optional, default `3600` seconds; minimum 3600 seconds.
- Existing Telegram/Kalshi credentials and DATA_DIR remain unchanged.

Do not paste API keys into Telegram, GitHub, or ChatGPT. Use Railway's environment-variable settings.

## Telegram commands
- `/aion`: start live independent AI assessments (about every 60 seconds with complete BRTI candles).
- `/aioff`: stop live AI calls.
- `/ai`: latest AI assessment.
- `/researchon`: start automatic hourly research tests.
- `/researchoff`: stop automatic research.
- `/auditai`: queue a research test now.
- `/improvements`: view most recent candidate proposal and holdout comparison.
- `/compare`: same comparison view.
- Existing `/shadowon`, `/shadow`, `/shadowoff` remain available.

## Safety and limitations
- AI is OFF by default; research is OFF by default. Both must be enabled explicitly after deployment.
- AI results are independent and NEVER change the official prediction engine, orders, source code, or settings.
- AI developer currently proposes **parameter configurations and patch plans**, not executable autonomous code patches. No GitHub write access or Railway deployment permission is granted.
- Research requires at least 30 unique, verified settled contracts that also have recorded AI assessments; one first observation per contract is used.
- The research sweep uses a chronological 70/30 train/test split; its small test set is exploratory, not proof of predictive advantage. Repeated testing on the same holdout can overfit. Require fresh forward validation and explicit approval before manually implementing any change.
- Live AI calls are asynchronous so slow API responses don't block the 5-second market monitor. If the AI fails, KeKe's original forecast continues.
- The AI does not learn or update its own model weights. Improvement means logged outcomes, deterministic candidate evaluation, and written recommendations.
- Current implementation does not provide full historical tick-by-tick replay or automatic GitHub pull requests. Those would be separate, approval-gated extensions.

## Verification
- Python source compiled successfully in the creation environment.
- Integration and simulated local tests run without contacting Kalshi, Telegram, Railway, or OpenAI.
- Not live-deployed or end-to-end tested with your credentials.
